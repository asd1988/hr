﻿namespace CRIF
{
    partial class NewForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewForm1));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CmbSubmissionType = new System.Windows.Forms.ComboBox();
            this.txtapp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 229);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(284, 33);
            this.button1.TabIndex = 0;
            this.button1.Text = "Create File";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(284, 229);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // CmbSubmissionType
            // 
            this.CmbSubmissionType.FormattingEnabled = true;
            this.CmbSubmissionType.Items.AddRange(new object[] {
            "STANDARD",
            "CORRECTION/HISTORY"});
            this.CmbSubmissionType.Location = new System.Drawing.Point(0, 206);
            this.CmbSubmissionType.Name = "CmbSubmissionType";
            this.CmbSubmissionType.Size = new System.Drawing.Size(284, 21);
            this.CmbSubmissionType.TabIndex = 2;
            // 
            // txtapp
            // 
            this.txtapp.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtapp.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtapp.Location = new System.Drawing.Point(0, 0);
            this.txtapp.Name = "txtapp";
            this.txtapp.Size = new System.Drawing.Size(100, 20);
            this.txtapp.TabIndex = 3;
            this.txtapp.Text = "0";
            this.txtapp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NewForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.txtapp);
            this.Controls.Add(this.CmbSubmissionType);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "NewForm1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CRIF";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox CmbSubmissionType;
        private System.Windows.Forms.TextBox txtapp;
    }
}

