﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRIF
{
    class Connection
    {
        public static  string con()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["con"].ConnectionString;
         
        }
    }
}
