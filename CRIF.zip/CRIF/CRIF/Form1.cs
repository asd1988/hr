﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.IO;
namespace CRIF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public Boolean InvValidate()
        {


            return true;
        }
        public DataSet GetData(string str)
        {
            try
            {

                DataSet ds = new DataSet();
                Connection cc = new Connection();
                SqlConnection con = new SqlConnection(Connection.con());
                SqlCommand sqlComm = new SqlCommand(str, con);
                //  sqlComm.Parameters.Add("@EmpDeductionID", obj.EmpDeductionID);
                sqlComm.CommandType = CommandType.Text;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;

                da.Fill(ds);
                return ds;
            }
            catch (SqlException ex)
            {
                string ss = ex.Message;
                return null;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            try
            {

                ShowProgress();//سبلاش سكرين
                string path= Convert.ToString ( System.Configuration.ConfigurationManager.AppSettings["Path"]);//يتم قراءة المسار الذي سيتم انشاء الملف عليه
                path = System.Configuration.ConfigurationManager.AppSettings["Path"];
                string FileName = "FIRSTFIN_CSDF_" + DateTime.Now.ToString("yyyyMMddHHmmss");//يتم انشاء الملف حيث ينقسم اسم اللمف الى ثلاثة اجزاء
                //1-كود الشركة لدى شركة كريفFIRSTFIN
                //2-CSDF رمز ثابت
                //التاريخ والوقت مع ضرورة الانتباه الى ان يكون فورمات التاريخyyyyMMddHHmmss
               
                File.Create(path+ FileName + ".txt").Dispose();//بدء عملية انشاء الملف
                var theDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1, 12, 12, 12);//يتم انشاء تاريخ بنفس الشهر والسنة واعطاء بداية الشهر
                //اول ريكور سيتم انشائهheader
                //نوع الريكورد HD

                string strHeader = "select 'HD' as [Record Type],'FIRSTFIN'as [Provider Code],";
                strHeader +="       REPLACE(cast(  CONVERT(VARCHAR(10),   dateadd(day,-1,cast((cast( month(getdate()) as nvarchar(10))+'.'+'1'+'.'+ cast(year(getdate())as nvarchar(10)))as date)),104) as nvarchar(max)),'.','')as [File Reference Date],";//اخر يوم من الشهر السابق
                strHeader +="       '1.0'as Version,";//دائما واحد
                strHeader +="      '"+ Convert.ToString  (           CmbSubmissionType.SelectedIndex)+"'as [Submission Type],";//عند ارسال الملف اول مرة كل شهر يتم اختيار الخيار الاول في حال ارسال الملف ورجوع بعض الريكورد بعد تصحيحيها واعادة ارساله نختار الخيار الثاني من القادروب داون لست
                strHeader += "      ''as [Provider Comments]";//غير ضروري;
                DataSet DsHeader = GetData(strHeader);//يتم تنفيذ الامر اعلاه
                //بداية نسخ ريكورد الهيدر في الملف
                string HeaderText = Convert.ToString(DsHeader.Tables[0].Rows[0]["Record Type"]) + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["Provider Code"]) + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["File Reference Date"]) + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["Version"]);
                HeaderText += "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["Submission Type"]) + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["Provider Comments"]);
                File.AppendAllText(path + FileName + ".txt", HeaderText + Environment.NewLine );
               //يتم الانتهاء من نسخ الهيدر بالملف

                //ستم انشاء ريكوردات التفصيلية الافراد والشركات
                string strDetail = " SELECT  DISTINCT ccif.phsicalMoral.phmrType,";//نوع الملف
                 strDetail += "       REPLACE(cast(  CONVERT(VARCHAR(10),   dateadd(day,-1,cast((cast( month(getdate()) as nvarchar(10))+'.'+'1'+'.'+ cast(year(getdate())as nvarchar(10)))as date)),104) as nvarchar(max)),'.','')as [File Reference Date],";//تاريخ اخر يوم من شهر السابق
                 strDetail += "      isnull(ccif.phsicalMoral.natCtryCode,1)as natCtryCode";//الجنسية;
                 strDetail += "     , isnull(ccif.phsicalMoral.allHomeAdrs,'-')as allHomeAdrs";//عنوان المنزل
                 strDetail += "     ,ccif.phsicalMoral.allWorkAdrs,";//عنوان العمل
                 strDetail += "     REPLACE(cast(  CONVERT(VARCHAR(10), ifod.applications.firstInstlDate,104) as nvarchar(max)),'.','')  as firstInstlDate,";//تاريخ اول قسط
                 strDetail += "     ccif.phsicalMoral.phmrBShortName, ";//الاسم بالعربي
                 strDetail += "     ccif.phsicalMoral.phmrSShortName, ";//الاسم بالانجليزي
                 strDetail += "     ccif.phsicalMoral.phmrId , ";//رقم الملف الاساسي
                 strDetail += "     ifod.applications.applId ,";//رقم المعاملة
                 strDetail += "     ifod.applications.custId, ";//رقم العميل
                 strDetail += "     REPLACE(cast(  CONVERT(VARCHAR(10), ifod.applications.applDate,104) as nvarchar(max)),'.','')  as applDate";//تاريخ قديم الطلب
                 strDetail += "     , ifod.applications.applComments1, ";//ملاحظات
                 strDetail += "     ifod.applications.brchCode, ";//الفرع
                 strDetail += "     REPLACE(cast(  CONVERT(VARCHAR(10), ifod.applications.applSignContDate,104) as nvarchar(max)),'.','')  as applSignContDate";//تاريخ توقيع المعاملة
                 strDetail += "     , ccif.phsicalMoral.phmrId";
                 strDetail += "     , isnull(ccif.phsicalMoral.phmrBName1,ccif.phsicalMoral.phmrBName)as phmrBName1 ,";//الاسم الاول-عربي
                 strDetail += "     isnull(ccif.phsicalMoral.phmrBName2,ccif.phsicalMoral.phmrBName)as phmrBName2, ";//اسم الاب-عربي
                 strDetail += "       isnull(ccif.phsicalMoral.phmrBName3,ccif.phsicalMoral.phmrBName)as phmrBName3,";//اسم الجد-عربي
                 strDetail += "     isnull(ccif.phsicalMoral.phmrBName4,ccif.phsicalMoral.phmrBName)as phmrBName4,";//اسم العائلة-عربي
                 strDetail += "     ccif.phsicalMoral.phmrBName,";//الاسم -عربي
                 strDetail += "     ccif.phsicalMoral.phmrSName1, ";//الاسم الاول-انجليزي
                 strDetail+="       ccif.phsicalMoral.phmrSName2, ";//اسم الاب-انجليزي
                 strDetail += "     ccif.phsicalMoral.phmrSName3, ";//اسم الجد-انجليزي
                 strDetail += "     ccif.phsicalMoral.phmrSName4,";//اسم العائلة-انجليزي
                 strDetail += "     ccif.phsicalMoral.phmrSName, ";//الاسم -انجليزي
                 strDetail += "     ccif.phsicalMoral.motherName,";//اسم الام
                 strDetail += "    (case ccif.phsicalMoral.genderCode when 1 then 'M' else 'F' end)as genderCode";//الجنس
                 strDetail += "    ,  REPLACE(cast(  CONVERT(VARCHAR(10), isnull(ccif.phsicalMoral.BirthOfDate,getdate()),104) as nvarchar(max)),'.','')  as   BirthOfDate,";//تاريخ الولادة
                 strDetail += "    ccif.phsicalMoral.birthCtryCode, ";//رمز مدينة الولادة
                 strDetail += "    ccif.phsicalMoral.birthPlaceLoc,";//مكان الولادة
                 strDetail += "    ccif.phsicalMoral.numOfChilds,";//عدد الاطفال
                 strDetail += "    ccif.phsicalMoral.fsitCode,";//الحالة الاجتماعية
                 strDetail += "    (case ccif.phsicalMoral.titlCode when 1 then 10 when 2 then 11 when 3 then 13 when 5 then 14 else 10 end )as titlCode,";//المسمى الوظيفي
                 strDetail += "    ccif.phsicalMoral.spouseName, ";//اسم الزوجة

                 strDetail += "    (select   ccif.physicalMoralAddresses.adrsPostCode from  ccif.physicalMoralAddresses ";//نوع العنوان
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as adrsPostCode,";
                 strDetail += "    (select   ccif.physicalMoralAddresses.streetName from  ccif.physicalMoralAddresses ";
                 strDetail+="      where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as streetName,";//الشارع
                 strDetail += "    (select   ccif.physicalMoralAddresses.cityCode from  ccif.physicalMoralAddresses ";
                 strDetail += "   where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as cityCode,";//المدينة
                 strDetail += "    1as adrsType,  ";//نوع العنوان
                 strDetail += "    (select   ccif.physicalMoralAddresses.govntCode from  ccif.physicalMoralAddresses ";
                 strDetail += "    where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as govntCode,";//المحافظة
                 strDetail += "    (select   ccif.physicalMoralAddresses.lctyCode from  ccif.physicalMoralAddresses ";
                 strDetail += "    where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as lctyCode,";//المنطقة
                 strDetail += "    (select   ccif.physicalMoralAddresses.areaLoc from  ccif.physicalMoralAddresses ";
                 strDetail += "    where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail +="     ) as areaLoc,";
                 strDetail += "    (select   ccif.physicalMoralAddresses.crtyCode from  ccif.physicalMoralAddresses ";
                 strDetail += "    where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as crtyCode,";
                 strDetail += "    (select   ccif.physicalMoralAddresses.buildingNo from  ccif.physicalMoralAddresses ";
                 strDetail += "    where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";
                        
                 strDetail += "    ) as buildingNo,";//المبنى
                 strDetail += "    (select  top(1) ccif.physicalMoralAddresses.adrsTel1 from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId ";

                 strDetail += "     ) as adrsTel1,";//الهاتف
                 strDetail += "    (select   ccif.physicalMoralAddresses.adrsFaxNo from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";

                 strDetail += "     ) as adrsFaxNo,";//فاكس
                 strDetail += "     (select   ccif.physicalMoralAddresses.adrsMail1 from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=1";

                 strDetail += "      ) as adrsMail1,";//موبايل
                 strDetail += "       (select top(1)   ccif.physicalMoralAddresses.adrsMobile1 from  ccif.physicalMoralAddresses ";
                 strDetail += "       where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId";
                        
                 strDetail += "      ) as adrsMobile1,";//موبايل
                 strDetail += "       (select   top(1)  ccif.physicalMoralAddresses.adrsPostCode from  ccif.physicalMoralAddresses"; 
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId ";
                        
                 strDetail += "      ) as adrsPostCode2,";
                 strDetail += "      (select   ccif.physicalMoralAddresses.streetName from  ccif.physicalMoralAddresses"; 
                 strDetail += "      where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "     ) as streetName2,";//الشارع
                 strDetail += "      (select   ccif.physicalMoralAddresses.cityCode from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "     ) as cityCode2,";
                 strDetail += "     1as adrsType,  ";
                 strDetail += "     (select   ccif.physicalMoralAddresses.govntCode from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "     ) as govntCode2,";
                 strDetail += "     (select   ccif.physicalMoralAddresses.lctyCode from  ccif.physicalMoralAddresses ";
                 strDetail += "     where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "       ) as lctyCode2,";
                 strDetail += "       (select   ccif.physicalMoralAddresses.areaLoc from  ccif.physicalMoralAddresses ";
                 strDetail += "       where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "    ) as areaLoc2,";
                 strDetail += "     (select   ccif.physicalMoralAddresses.crtyCode from  ccif.physicalMoralAddresses ";
                 strDetail += "      where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "      ) as crtyCode2,";
                 strDetail += "       (select   ccif.physicalMoralAddresses.buildingNo from  ccif.physicalMoralAddresses ";
                 strDetail += "      where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "      ) as buildingNo2,";
                 strDetail += "        (select   ccif.physicalMoralAddresses.adrsMobile1 from  ccif.physicalMoralAddresses ";
                 strDetail += "      where ccif.phsicalMoral.phmrId  = ccif.physicalMoralAddresses.phmrId and  ccif.physicalMoralAddresses.adrsSeq=2  and  ccif.physicalMoralAddresses.adrsType=2";
                        
                 strDetail += "    ) as adrsMobile12,";
                 strDetail += "    ccif.phsicalMoral.phmrNationalNum, ";
                 strDetail += "    ccif.phsicalMoral.DcntCode,";
                 strDetail += "    ccif.phsicalMoral.idDocNum, ";
                 strDetail += "    ccif.phsicalMoral.idDocIssuePlace, ";
                 strDetail += "    REPLACE(cast(  CONVERT(VARCHAR(10), ccif.phsicalMoral.idDocIssueDate,104) as nvarchar(max)),'.','')  as idDocIssueDate,";
                 strDetail += "    REPLACE(cast(  CONVERT(VARCHAR(10), ccif.phsicalMoral.idDocEndDate,104) as nvarchar(max)),'.','')  as idDocEndDate,";
                 strDetail += "    ccif.phsicalMoral.companyActivity, ";
                 strDetail += "    ccif.phsicalMoral.lglsCode, ";
                 strDetail += "    ccif.phsicalMoral.commRegNbr ,";
                 strDetail += "    REPLACE(cast(  CONVERT(VARCHAR(10), ccif.phsicalMoral.comRegDate ,104) as nvarchar(max)),'.','')as comRegDate";
                 strDetail += "    , (case ifod.applications.apstCode when 10 then 'CL' when 13 then 'AC' when 3 then 'RQ' when 9 then 'RF' else cast( ifod.applications.apstCode as nvarchar(250)) end )as apstCode, ";//حالة المعاملة
                 strDetail += "     ifod.applications.applCompanySpecialDiscountPrc, ";
                 strDetail += "     REPLACE(cast(  CONVERT(VARCHAR(10), ifod.applications.lastInstlDate ,104) as nvarchar(max)),'.','')as lastInstlDate,";
                // strDetail += "    REPLACE(cast(  CONVERT(VARCHAR(10), case ifod.applications.apstCode when 10 then( SELECT    max( TrackingDate )FROM         ifod.ApplicationBalances WHERE     (ApplID = ifod.applications.applId )and month(TrackingDate)<month(getdate())) else (SELECT    max( instPaidDate) FROM         ifod.applInstallmentSchedule WHERE     (applId = ifod.applications.applId))end,104) as nvarchar(max)),'.','') as lastpaid,";//تاريخ اخر قسط
                 strDetail += "                       REPLACE(cast(  CONVERT(VARCHAR(10), isnull((SELECT    max( instPaidDate)    FROM         ifod.applInstallmentSchedule   WHERE  month(instPaidDate)< month(getdate())and   (applId = ifod.applications.applId)),(SELECT    max( TrackingDate )   FROM         ifod.ApplicationBalances WHERE        (ApplID = ifod.applications.applId)and month(TrackingDate)<month(getdate()))),104) as nvarchar(max)),'.','') as lastpaid,";
                 strDetail += "     ifod.applications.totFinAmt,";//مبلغ التمويل
                 strDetail += "     ifod.applications.realPaymentsNbr, ";//عدد الاقساط
                 strDetail+="      ifod.applications.monthlyPayment, ";//القسط الشهري
                 strDetail+="      (select top(1) grtsSeq from ifod.grteesApplD where ifod.applications.applId = ifod.grteesApplD.applId) as grtsSeq";//الضمانة
                 strDetail+="      , (select top(1) grteesAmnt from ifod.grteesApplD where ifod.applications.applId = ifod.grteesApplD.applId) as grteesAmnt";//قيمة الضمانة
                 strDetail+="      ,(select top(1) ifod.grteesM.grtsExpiryDate from ifod.grteesApplD inner join ifod.grteesM on ifod.grteesApplD.grtsSeq = ifod.grteesM.grtsSeq where ifod.applications.applId = ifod.grteesApplD.applId) as grtsExpiryDate";//نتهاء ضمانة
                 strDetail+="      ,(select top(1) ifod.grteesM.gtypCode from ifod.grteesApplD inner join ifod.grteesM on ifod.grteesApplD.grtsSeq = ifod.grteesM.grtsSeq where ifod.applications.applId = ifod.grteesApplD.applId) as gtypCode";//رمز الضمانة
                 strDetail += "     , (SELECT    case isnull(Collection.Classifications.ClassificationID,0) when 0 then 0";
                 strDetail += "       when 7 then 1 when 1 then 2 when 2 then 3 when 3 then 4 when 4 then 5 when 5 then 6 when 6 then 8 end  ";
                 strDetail += "     FROM         Collection.Cases INNER JOIN";
                 strDetail += "     Collection.Classifications ON Collection.Cases.ClassificationID = Collection.Classifications.ClassificationID";
                 strDetail += "     WHERE     (ApplID = ifod.applications.applId  )) as [Days Past Due]";

                 strDetail += "      , isnull( (SELECT     sum(instTotAmt)";
                 strDetail += "    FROM         ifod.applInstallmentSchedule";
                 strDetail += "    WHERE     (applId =  ifod.applications.applId ) AND (instClaimDate <= GETDATE())and (instTotAmt<> instPaidAmt)),0)as [Overdue Payments Amount]";

                 strDetail += "     ,  isnull((SELECT     count(instTotAmt)";
                 strDetail += "    FROM         ifod.applInstallmentSchedule";
                 strDetail += "    WHERE    (instTotAmt<>0)and (applId =  ifod.applications.applId )AND (instClaimDate <= GETDATE()) and (instTotAmt<> instPaidAmt)),0)as [Overdue Payments Number]";
               //  strDetail += "     ,  isnull((SELECT  top(1)   Balance";
               //  strDetail += "    FROM         ifod.ApplicationBalances";
               //  strDetail += "    WHERE     (applId =  ifod.applications.applId )and(TrackingDate <= GETDATE())ORDER BY TrackingDate DESC),0)as [Outstanding Balance]";
                 strDetail += "     , isnull( (SELECT     sum(instTotAmt)";
                 strDetail += "    FROM         ifod.applInstallmentSchedule";
                 strDetail += "    WHERE     (ifod.applInstallmentSchedule.applId =   ifod.applications.applId) AND (instClaimDate >=getdate())and ((instTotAmt<> instPaidAmt)  )),0)as [Outstanding Balance]";
                strDetail += "    ,(case ccif.applMembers.appmType when 1 then case ccif.applMembers.clientGurantorFlg when 1 then   'B' else 'G' end else 'G' end )as ROLES";
                 strDetail += "     , isnull( (SELECT     count(instTotAmt)";
                 strDetail += "    FROM         ifod.applInstallmentSchedule";
                 strDetail += "    WHERE     (ifod.applInstallmentSchedule.applId =   ifod.applications.applId) AND (instClaimDate >=getdate())and ((instTotAmt<> instPaidAmt)  )),0)as [Outstanding Payments Number]";
                 strDetail += "    FROM         ifod.applications INNER JOIN";
                 strDetail += "    ccif.applMembers ON ifod.applications.applId = ccif.applMembers.appId INNER JOIN";
                 strDetail += "    ccif.phsicalMoral ON ccif.applMembers.phmrId = ccif.phsicalMoral.phmrId ";
                 strDetail += "    LEFT OUTER JOIN";
                 strDetail += "   ccif.custMembers ON ccif.phsicalMoral.phmrId = ccif.custMembers.phmrId AND ifod.applications.custId = ccif.custMembers.custId";
                 strDetail += "   RIGHT OUTER JOIN";
                 strDetail += "   ifod.applReqDocuments ON ifod.applications.applId = ifod.applReqDocuments.applId and ccif.applMembers.phmrId = ifod.applReqDocuments.phmrId";
              //   strDetail += "   WHERE     (ifod.applDocuments.dcmntCode = 28)";
                //سيت جلب المعاملات التي حالتها عمليات فقط والتي قام اصحاب المعاملات بتسليم اقرار استعلام كريف كماتم استثناء معاملات العميل سلوى عتيق30078 
                 strDetail += "   where (ifod.applications.apstCode=13 or ifod.applications.apstCode=10 ) and ccif.phsicalMoral.phmrId not in (38570,13957,30078,37505) and ccif.phsicalMoral.phmrId<>35543 and  ifod.applications.applSignContDate<dateadd(day,-1,cast('" + theDate + "' as date))";
                strDetail += " and   (select count( TrackingDate ) from ifod.ApplicationBalances where ApplID=ifod.applications.applId and TrackingDate <= dateadd(day,-1,cast('" + theDate + "' as date)))>0";
                strDetail += "   and (ifod.applReqDocuments.dcmntCode = 28) AND (ifod.applReqDocuments.dcmntRecvFlg = 1)and (ifod.applications.applId not in(16879)) ";
                if (txtapp.Text != "0")
                {
                    strDetail += "   and ifod.applications.applId="+txtapp.Text+"";

                }
                strDetail += "   ORDER BY ifod.applications.applId";
                    DataSet DSDetail = GetData(strDetail);//تم تنفيذ جملة السليكت اعلاه
                    Int32 index = 0;
                    string DetailText = " ";
                    while (index <= DSDetail.Tables[0].Rows.Count -1)
                    {
                        try{
                        if (Convert.ToInt16(DSDetail.Tables[0].Rows[index]["phmrType"]) == 1)//اذا نوع الريكورد افراد سيقوم بدخول ادناه ونسخ معلومات الخاصة بملف العميل
                        {
                            //ترميز الافراد ID
                            DetailText = "ID" + "|" + "FIRSTFIN";//Record Type|Provider Code
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["brchCode"]);//brchCode
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["File Reference Date"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrId"]);//Subject Reference Date + Provider Subject No
                            DetailText += "|" + "" + "|" + "";//  First Name English +  Last Name English
                            DetailText += "|" + "" + "|" + "";//  Middle Name English + Mother First Name English
                            DetailText += "|" + "" + "|" + "";//  Father First Name English + Grandfather First Name English
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName1"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName4"]);//First Name Arabic + Last Name Arabic
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName2"]) + "|" + "" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName2"]);// Middle Name Arabic + Mother First Name Arabic
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName3"]);//Grandfather First Name Arabic
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["genderCode"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["BirthOfDate"]);//Gender + Date of Birth
                            DetailText += "|" + "";//Place of Birth

                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "1")
                            {
                                DetailText += "|" + "" + "|" + "JO";//Country of Birth (Code) + national code
                            }
                            
                             else   if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "2")
                                {
                                    DetailText += "|" + "" + "|" + "PS";// Country of Birth (Code) + national code
                                }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "3")
                            {
                                DetailText += "|" + "" + "|" + "IQ";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "4")
                            {
                                DetailText += "|" + "" + "|" + "SY";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "5")
                            {
                                DetailText += "|" + "" + "|" + "LB";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "105")
                            {
                                DetailText += "|" + "" + "|" + "CA";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "7")
                            {
                                DetailText += "|" + "" + "|" + "SA";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "8")
                            {
                                DetailText += "|" + "" + "|" + "KW";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "14")
                            {
                                DetailText += "|" + "" + "|" + "OM";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "51")
                            {
                                DetailText += "|" + "" + "|" + "EG";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "62")
                            {
                                DetailText += "|" + "" + "|" + "MO";//Country of Birth (Code) + national code
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "201")
                            {
                                DetailText += "|" + "" + "|" + "US";//Country of Birth (Code) + national code
                            }
                            DetailText += "|" + "" + "|" + "" + "|" + "";//Marital Status  + Name of spouse + Number of legal dependants
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["titlCode"]) + "|" + "MI";//Title + Address 1: Type
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["allHomeAdrs"]).Length >1)
                         {
                             DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["allHomeAdrs"]) + "|" + "";//Address 1: FullAddress + Address 1: StreetNameNo
                         }
                         else
                         {
                             DetailText += "|" + "-" + "|" + "";//Address 1: FullAddress + Address 1: StreetNameNo
                         }

                            DetailText += "|" + "" + "|" + "";//Address 1: ZIPCode + Address 1: City
                            DetailText += "|" + "" + "|" + "";//Address 1: District + Address 1: Province
                            DetailText += "|" + "" + "|" + "";//Address 1: Governatorate + Address 1: Building Ownership 
                            DetailText += "|" + "" + "|" + "";//Address 1: Country + Address 1: POBoxNo 
                            DetailText += "|" + "";//Address 2: Address Type
                            DetailText += "|" + "" + "|" + "";//Address 2: FullAddress + Address 2: StreetNameNo
                            DetailText += "|" + "" + "|" + "";//Address 2: ZIPCode + Address 2: City
                            DetailText += "|" + "" + "|" + "";//Address 2: District + Address 2: Province
                            DetailText += "|" + "" + "|" + "";//Address 2: Governatorate + Address 2: Building Ownership 
                            DetailText += "|" + "" + "|" + "";//Address 2: Country + Address 2: POBoxNo 

                          
                           
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "1")
                            {
                                DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrNationalNum"]);//Identification Code 1: Type + Identification Code 1: Number
                            }
                            else
                            {
                                DetailText += "|" + "" + "|" + "";//Identification Code 1: Type +Identification Code 1: Number
                                DetailText += "|" + "" + "|" + "";//Identification Code 2: Type +Identification Code 2: Number
                            }
                        
                     
                            //-------------------------------------------------
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["natCtryCode"]) == "1")
                            {
                                DetailText += "|" + "" + "|" + "";//Identification Code 1: Type +Identification Code 1: Number
                                DetailText += "|" + "" + "|" + "";//Identification Code 2: Type +Identification Code 2: Number
                            }



                            else if ((Convert.ToString(DSDetail.Tables[0].Rows[index]["DcntCode"]) == "5") || (Convert.ToString(DSDetail.Tables[0].Rows[index]["DcntCode"]) == "6"))
                            {

                                DetailText += "|" + "5" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["idDocNum"]);//ID 1:Type + ID 1: Number
                            }
                            else if ((Convert.ToString(DSDetail.Tables[0].Rows[index]["DcntCode"]) == "2") || (Convert.ToString(DSDetail.Tables[0].Rows[index]["DcntCode"]) == "3"))
                            {

                                DetailText += "|" + "3" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["idDocNum"]); //ID 1:Type + ID 1: Number
                            }
                            else
                            {

                                DetailText += "|" + "" + "|" + "";//ID 1:Type + ID 1: Number
                            }


                            DetailText += "|" + "" + "|" + "";//ID 1: IssueDate + ID 1: IssueCountry
                            DetailText += "|" + "" + "|" + "";//D 1: ExpiryDate + ID 2:Type
                            DetailText += "|" + "" + "|" + "";//ID 2: Number +ID 2: IssueDate 
                            DetailText += "|" + "" + "|" + "";//ID 2: IssueCountry +D 2: ExpiryDate
                            DetailText += "|" + "" + "|" + "";//ID 3:Type + ID 3: Number
                            DetailText += "|" + "" + "|" + "" + "|" + "";//ID 3: IssueDate + ID 3: IssueCountry + D 3: ExpiryDate
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile1"]).Length >5)
                            {
                                DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile1"]);//Contact 1: Type + Contact 1: Value
                            }
                            else if (Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsTel1"]).Length > 5)
                            {

                                DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsTel1"]);//Contact 1: Type + Contact 1: Value
                            }
                            else
                            {


                                DetailText += "|" + "1" + "|" + "-";//Contact 1: Type + Contact 1: Value
                            }
                            DetailText += "|" + "" + "|" + "";//Contact 2: Type + Contact 2: Value
                            DetailText += "|" + "" + "|" + "";//Contact 3: Type + Contact 3: Value
                            DetailText += "|" + "" + "|" + "";//Contact 4: Type + Contact 4: Value
                            DetailText += "|" + "" + "|" + "";//Employment: Employer Trade Name + Employment: Address 
                            DetailText += "|" + "" + "|" + "";//Employment: GrossIncome + Employment: Currency
                            DetailText += "|" + "" + "|" + "";// Employment: OccupationStatus + Employment: DateHired
                            DetailText += "|" + "" + "|" + "";//Employment: Occupation + Sole Trader:  Official Registred Trade Name English
                            DetailText += "|" + "" + "|" + "";//Sole Trader:  Official Registred Trade Name Arabic + Business Registration Number
                            DetailText += "|" + "" + "|" + "";//Business Registration Date + Soletrader Address 1: Type
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 1: Full Address + Soletrader Address 1: StreetNameNo
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 1: ZIPCode + Soletrader Address 1: City
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 1: District +Soletrader Address 1: Province
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 1: Governatorate + Soletrader Address 1: Building Ownership 
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 1: Country +Soletrader Address 1: POBoxNo 
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: Type + Soletrader Address 2: Full Address
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: StreetNameNo + Soletrader Address 2: ZIPCode
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: City + Soletrader Address 2: District
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: Province + Soletrader Address 2: Governatorate
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: Building Ownership  + Soletrader Address 2: Country
                            DetailText += "|" + "" + "|" + "";//Soletrader Address 2: POBoxNo  +Sole Trader Identification Code 1: Type
                            DetailText += "|" + "" + "|" + "";//Sole Trader  Identification Code 1: Number +Sole Trader Identification Code 2: Type
                            DetailText += "|" + "" + "|" + "";//Sole Trader  Identification Code 2: Number +Sole Trader Contact 1: Type
                            DetailText += "|" + "" + "|" + "";//Sole Trader Contact 1:Value +Sole Trader Contact 2:Type
                            DetailText += "|" + "";//Sole Trader Contact 2: Value
                            DetailText += "|" + "" + "|" + "";//في حال وجود اخر الريكور زيادة لايؤثر عقراءة الملف
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                        }
                        else//شركات
                        {
                            //يتم ترميز ريكورد الشركات BD
                            DetailText = "BD" + "|" + "FIRSTFIN";//Record Type|Provider Code
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["brchCode"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["File Reference Date"]);//brchCode + Subject Reference Date + Provider Subject No
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrId"]);//Provider Subject No
                            DetailText += "|" + "";//Official Registered Name English
                            DetailText += "|" + "" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrBName"]);//Trade Name English + Official Registred Name Arabic
                            DetailText += "|" + "" + "|" + "";//Trade Name Arabic  + Legal Form
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["commRegNbr"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["comRegDate"]);//Business Registration Number + Business Registration Date
                            DetailText += "|" + "" + "|" + "";//Industry code+Number of employees
                            DetailText += "|" + "" + "|" + "MT";//Gross income/ Annual Turnover + Address 1: Type
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["allHomeAdrs"]).Length > 1)
                            {
                                DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["allHomeAdrs"]) + "|" + "";//Address 1: FullAddress +Address 1: StreetNameNo
                            }
                            else
                            {
                                DetailText += "|" + "-" + "|" + "";//Address 1: FullAddress +Address 1: StreetNameNo
                            }
                            DetailText += "|" + "" + "|" + "";//Address 1: ZIPCode + Address 1: City
                            DetailText += "|" + "" + "|" + "";//Address 1: District + Address 1: Province
                            DetailText += "|" + "" + "|" + "";//Address 1: Governatorate + Address 1: Building Ownership 
                            DetailText += "|" + "" + "|" + "";//Address 1: Country + Address 1: POBoxNo 
                            DetailText += "|" + "";//Address 2: Type

                            DetailText += "|" + "" + "|" + "";//Address 2: FullAddress +Address 1: StreetNameNo
                            DetailText += "|" + "" + "|" + "";//Address 2: ZIPCode + Address 1: City
                            DetailText += "|" + "" + "|" + "";//Address 2: District + Address 1: Province
                            DetailText += "|" + "" + "|" + "";//Address 2: Governatorate + Address 1: Building Ownership
                            DetailText += "|" + "";//Address 2: Country 
                           
                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrNationalNum"]).Length ==9)
                            {
                                DetailText += "|" + "" + "|" + "1";//Address 1: POBoxNo +Identification Code 1: Type
                                DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrNationalNum"]) + "|" + "";//Identification Code 1: Number + Identification Code 2: Type
                            }
                            else{
                                DetailText += "|" + "" + "|" + "1";//Address 1: POBoxNo +Identification Code 1: Type
                                DetailText += "|" + "" + "|" + "";//Identification Code 1: Number + Identification Code 2: Type
                            }
                            DetailText += "|" + "";//Identification Code 2: Number


                            if (Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile1"]).Length > 2)
                            {
                                DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile1"]);//Contact 1: Type +Contact 1: Value
                            }

                            else
                            {
                                if (Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsTel1"]).Length > 2)
                                {
                                    DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsTel1"]);//Contact 1: Type +Contact 1: Value
                                }
                                else
                                {
                                    if (Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile12"]).Length > 2)
                                    {
                                        DetailText += "|" + "1" + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["adrsMobile12"]);//Contact 1: Type +Contact 1: Value
                                    }
                                    else
                                    {
                                        DetailText += "|" + "1" + "|" + "-";//Contact 1: Type +Contact 1: Value
                                    }
                                }
                            }

                            DetailText += "|" + "" + "|" + "" + "|" + "";//Contact 2: Type +Contact 2: Value
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                            DetailText += "|" + "" + "|" + "";
                            //خاص بمعاملات الافراد الكود ادناه SL

                            //DetailText +=  Environment.NewLine + "SL" + "|" + "FIRSTFIN";
                           // DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["brchCode"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["applSignContDate"]);
                           // DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrId"]);
                          //  DetailText += "|" + "P" + "|" + "0";

                        }
                 //ريكورد العقود سيحتوي معلومات المعاملة وسيتم ترميزه بCI
                        DetailText += Environment.NewLine + "CI" + "|" + "FIRSTFIN";//Record Type|Provider Code
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["brchCode"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["File Reference Date"]);//brchCode + Contract Reference Date

                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrId"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["ROLES"]);//Provider Subject No + Role 
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["applId"]) + "|" + "8";//Provider Contract No + Contract Type
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["apstCode"]) + "|" + "";//Contract Phase + Contract Status 
                        DetailText += "|" + "JOD" + "|" + "JOD";//Currency + Original Currency
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["applSignContDate"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["firstInstlDate"]);//Contract Start Date + Contract Request Date

                        if (Convert.ToString(DSDetail.Tables[0].Rows[index]["lastpaid"]).Length==0)
                            {
                                if (Convert.ToString(DSDetail.Tables[0].Rows[index]["apstCode"]) != "AC")
                                {
                                    DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastInstlDate"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["File Reference Date"]);//Contract End Planned Date + Contract End Actual Date
                                }
                                else
                                {
                                    DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastInstlDate"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastpaid"]);//Contract End Planned Date + Contract End Actual Date

                                }
                            }
                            else{
                            
                            DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastInstlDate"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastpaid"]);//Contract End Planned Date + Contract End Actual Date
                            }
                                DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["lastpaid"]) + "|" + "";//Last Payment Date + Reorganized Credit Code
                        DetailText += "|" + Convert.ToString(Convert.ToInt32(DSDetail.Tables[0].Rows[index]["totFinAmt"])) + "|" + "NA";//Financed Amount + Transaction Type / Sub-facility
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["realPaymentsNbr"]) + "|" + "M";//Installments Number + Payment Periodicity
                        DetailText += "|" + "CAS" + "|" + Convert.ToString(Convert.ToInt32(DSDetail.Tables[0].Rows[index]["monthlyPayment"]));//Payment Method + Monthly Payment Amount 
                        DetailText += "|" + "";//First Payment Date
                        DetailText += "|" + "" + "|" + "";//Next Payment Date + Next Payment
                        if (Convert.ToString(DSDetail.Tables[0].Rows[index]["apstCode"]) != "AC")
                        {
                            DetailText += "|" + 0 + "|" + Convert.ToString(Convert.ToInt32(0));//Outstanding Payments Number + Outstanding Balance
                        }
                        else
                        {

                            DetailText += "|" + Convert.ToString(Convert.ToInt32(DSDetail.Tables[0].Rows[index]["Outstanding Payments Number"])) + "|" + Convert.ToString(Convert.ToInt32(DSDetail.Tables[0].Rows[index]["Outstanding Balance"]));//Outstanding Payments Number + Outstanding Balance
                      
                        }
                                DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["Overdue Payments Number"]) + "|" + Convert.ToString(Convert.ToInt32(DSDetail.Tables[0].Rows[index]["Overdue Payments Amount"]));//Overdue Payments Number + Overdue Payments Amount
                        DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["Days Past Due"]) + "|" + "";//Days Past Due + Good Type
                        DetailText += "|" + "" + "|" + "";//Good Value + New/Used Code
                        DetailText += "|" + "" + "|" + "";//Good Brand + Manufacturing Date
                        DetailText += "|" + "" + "|" + "";//Registration number + Provider Guarantee No

                        DetailText += "|" + "" + "|" + "";//Provider Subject No (Guarantor) + Guarantor Name
                        DetailText += "|" + "";//Guaranteed Amount
                        DetailText += "|" + "" + "|" + "";//Currency + Validity Start Date
                        DetailText += "|" + "" + "|" + "";//Validity End Date + Guarantee Type

                        DetailText += "|" + "" + "|" + "";//Asset Code  + Asset Description
                        DetailText += "|" + "" + "|" + "";//Asset Location + Asset Appraised Value
                        DetailText += "|" + "" + "|" + "";//Customer Type + Provider Guarantee No
                        DetailText += "|" + "" + "|" + "";//Provider Subject No (Guarantor) + Guarantor Name
                        DetailText += "|" + "" + "|" + "";//Guaranteed Amount + Currency
                        DetailText += "|" + "" + "|" + "";//Validity Start Date + Validity End Date
                        DetailText += "|" + "" + "|" + "";//Guarantee Type + Asset Code 
                        DetailText += "|" + "" + "|" + "";//Asset Description + Asset Location
                        DetailText += "|" + "" + "|" + "";//Asset Appraised Value + Customer Type
                        DetailText += "|" + "" + "|" + "";//Provider Guarantee No + Provider Subject No (Guarantor)
                        DetailText += "|" + "" + "|" + "";//Guarantor Name + Guaranteed Amount
                        DetailText += "|" + "" + "|" + "";//Currency + Validity Start Date
                        DetailText += "|" + "" + "|" + "";//Validity End Date + Guarantee Type
                        DetailText += "|" + "" + "|" + "";//Asset Code  + Asset Description
                        DetailText += "|" + "" + "|" + "";//Asset Location + Asset Appraised Value
                        DetailText += "|" + "" + "|" + "";//Customer Type + Provider Guarantee No
                        DetailText += "|" + "" + "|" + "";//Provider Subject No (Guarantor) + Guarantor Name
                        DetailText += "|" + "" + "|" + "";// Guaranteed Amount + Currency
                        DetailText += "|" + "" + "|" + "";//Validity Start Date + Validity End Date
                        DetailText += "|" + "" + "|" + "";//
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                        DetailText += "|" + "" + "|" + "";
                            //ستم التاكد من ان المعامله لم يتم اتخاذ اي اجراء قانوني لها
                        string StrNegative = " SELECT  top(1)   REPLACE(cast(  CONVERT(VARCHAR(10), Collection.CaseActions.ActionDate,104) as nvarchar(max)),'.','')as   ActionDate, Collection.CaseActions.ActionDescription, Collection.Cases.ApplID";
                             StrNegative += " FROM         Collection.CaseActions INNER JOIN";
                             StrNegative += "    Collection.Cases ON Collection.CaseActions.CaseID = Collection.Cases.CaseID";
                             StrNegative += " WHERE     (Collection.CaseActions.CaseActionTypeID IN (18,19, 20, 21, 22, 23, 24, 25))and Collection.Cases.ApplID in (16165)and Collection.Cases.ApplID =" + Convert.ToString(DSDetail.Tables[0].Rows[index]["ApplID"]);
                             StrNegative += " ORDER BY Collection.Cases.ApplID DESC";
                             DataSet DSNegative = GetData(StrNegative);//ستم تنفيذ امر اعلاه
                             if (DSNegative.Tables[0].Rows.Count > 0)
                             {
                                 //في حال كان يوجد اجراء قانوني على المعاملة سيتم اذافة الريكورد ذو رمز NE
                                 DetailText += "|" + Environment.NewLine + "NE" + "|" + "FIRSTFIN";//Record Type|Provider Code
                                 DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["brchCode"]) + "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["File Reference Date"]);//brchCode + Negative Event Reference Date

                                 DetailText += "|" + Convert.ToString(DSDetail.Tables[0].Rows[index]["phmrId"]) + "|" + "Z";//Provider Subject No + Event Code   
                                 DetailText += "|" + "" + "|" + Convert.ToString(DSNegative.Tables[0].Rows[0]["ActionDate"]);//Event Detail + Event Date
                                 DetailText += "|" + "" + "|" + "";
                                 DetailText += "|" + "" + "|" + "";
                             }
                             File.AppendAllText(path + FileName + ".txt", DetailText + Environment.NewLine);
                       
                        index +=  1;
                        }
                        catch {
                          

                        }
                    }

                    //FTالفوتر ملخص الملف والذي سيحتوي ايضا عدد الريكورد التي تم ارسالها ويرمز للريكورد
                    string strFoter  = "  select 'FT' as [Record Type],";
                           strFoter += " 'FIRSTFIN'as [Provider Code],";
                           strFoter += "  REPLACE(cast(  CONVERT(VARCHAR(10), getdate(),104) as nvarchar(max)),'.','')as [File Reference Date]";
            
                    DataSet DsFoter = GetData(strFoter);
                    var lineCount = 0;
                    using (var reader = File.OpenText(path + FileName + ".txt"))
                    {
                        while (reader.ReadLine() != null)
                        {
                            lineCount++;
                        }
                   
                    }


                    string FoterText = "FT" + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["Provider Code"]) + "|" + Convert.ToString(DsHeader.Tables[0].Rows[0]["File Reference Date"]) + "|" + Convert.ToString(lineCount + 1);////Record Type|Provider Code|File Reference Date|Nr. of records
                    File.AppendAllText(path + FileName + ".txt", FoterText);
                  
   

                    CloseProgress();
                MessageBox.Show ("Okay...");
            }
            catch {
            
                }
        }
        public frmProgress frm = new frmProgress();
        private void CloseProgress()
        {
            System.Threading.Thread.Sleep(200);
            frm.Invoke(new Action(frm.Close));
        }
        private void ShowProgress()
        {

            try
            {
                if (this.InvokeRequired)
                {
                    try
                    {
                        frm.ShowDialog();
                    }
                    catch (Exception ex) { }
                }
                else
                {
                    System.Threading.Thread th = new System.Threading.Thread((ShowProgress));
                    th.IsBackground = false;
                    th.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CmbSubmissionType.SelectedIndex = 0;
        }
    }
}
